The examples for the tarfile module use this file and example.tar as
data.
